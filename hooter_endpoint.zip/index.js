"use strict";
const Alexa = require("alexa-sdk");
// const axios = require("axios");
// const HoursLookUp = require("./hoursLookUp.js").default;

//=========================================================================================================================================
//TODO: The items below this comment need attention.
//=========================================================================================================================================
const APP_ID = "amzn1.ask.skill.e896779a-a041-473e-9834-95af9e94d2f4";

// const SKILL_NAME = "Hooter Test";
// const WELCOME_MESSAGE = "Welcome to Hooter Skill, how can I help you";
// const HELP_MESSAGE =
//   "You can ask for building's hours or lastes news. Try saying when does tech center open.";
// const HELP_REPROMPT = "What can I help you with?";
// const STOP_MESSAGE = "Go Owl!";

//=========================================================================================================================================
//Editing anything below this line might break your skill.
//=========================================================================================================================================

const handlers = {
  "LaunchRequest": function () {
    const speechOutput = WELCOME_MESSAGE;
    const reprompt = HELP_REPROMPT;

    this.response.speak(speechOutput).listen(reprompt);
    this.emit(":responseReady");
  },
  "AMAZON.HelpIntent": function () {
    const speechOutput = HELP_MESSAGE;
    const reprompt = HELP_REPROMPT;

    this.response.speak(speechOutput).listen(reprompt);
    this.emit(":responseReady");
  },
  "AMAZON.CancelIntent": function () {
    this.response.speak(STOP_MESSAGE);
    this.emit(":responseReady");
  },
  "AMAZON.StopIntent": function () {
    this.response.speak(STOP_MESSAGE);
    this.emit(":responseReady");
  }
};
// const newSession = require("./handlers/newSession"); //testing
const defaultHandlers = require("./handlers/defaultHandlers.js");
const hoursLookUpHandler = require("./handlers/hoursLookUpHandler.js");

exports.handler = function (event, context, callback) {
  const alexa = Alexa.handler(event, context, callback);
  alexa.APP_ID = APP_ID;
  alexa.registerHandlers(defaultHandlers, hoursLookUpHandler);
  alexa.execute();
};
